/***********************************************************************
* 
*	File: Test.java
*
*	Project:  TwoNumbers
*   
*	Description:  This is part three of Lab3.  This is the test main of
*		      TwoNumbersTester
*
*	Author:  Joshua Wiley
*
*	Date:  2-15-15
*
*	Comments:  Specs were a little hard to follow. It wasn't clear what the
*		   Test program did until part three.  
* 
**********************************************************************/

public class Test
{
	public static void main(  String[] args )
	{
		TwoNumbersTester test = new TwoNumbersTester();
		test.startNumberTester();
	} 
}