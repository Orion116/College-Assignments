/***************************************************
*
* File: Project0.java
*
* Project: Project0
*
* Author: Joshua Wiley
*
* Date: 2-22-15
*
* Description: A test to make sure that my jave environment
*              is set up correctly.  
*
* Comments: Program runs as expected.
*
***************************************************/
public class Project0 // Class header
{
	public static void main( String argv[] ) // Main method
	{
		System.out.println( "\n   Hello World!" ); // Display string
	}
}