/**
 * @author Joshw
 */
import java.util.Scanner;
import java.lang.Math;

public class DownloadTimeApp
{
    public static void main( String[] args )
    {
        // display operational messages
        System.out.println ( "Welcome to the Download Time Estimator\n" );

        // initialize variables and create a Scanner object
        double fileSize = 0.0;
        double downloadSpeed = 0.0;
        String choice = "y";
        
        Scanner sc = new Scanner ( System.in );

        // get a series of test scores from the user
        while ( choice.equalsIgnoreCase ( "y" ) )
        {
            // get the input from the user
            System.out.print ( "Enter file size (MB): " );
            fileSize = sc.nextDouble();
            System.out.print ( "Enter download speed (MB/sec): " );
            downloadSpeed = sc.nextDouble();
            
            double totalSecondsDouble = fileSize / downloadSpeed;
            
            long totalSeconds = Math.round ( totalSecondsDouble );
            long hours = totalSeconds / ( 60 * 60 );
            long secondsRemainder = totalSeconds % ( 60 * 60 );
            long minutes = secondsRemainder / 60;
            long seconds = secondsRemainder % 60;
            
            System.out.println ();
            System.out.println ( "This download will take aprox: " +
                    hours + " hours " + minutes + " minutes " + seconds +
                    " seconds");
            System.out.print ( "Continue? (y/n): " );
            choice = sc.next ();
            System.out.println ();
        }
    }
}
