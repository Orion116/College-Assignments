import java.sql.*;

public class DBTesterApp
{
    private static Connection connection = null;
    
    public static void main(String args[])
    {
        // get the connection and start the Derby engine
        connection = MurachDB.getConnection();
        if (connection != null)
            System.out.println("Derby has been started.\n");
        
        // select data from database
        printProducts();
        printFirstProduct();
        printLastProduct();
        printProductByCode("java");

        Product p = new Product("test", "Test Product", 49.50);
        
        // modify data in the database
        insertProduct(p);
        printProducts();
        
        deleteProduct(p);
        printProducts();

        // disconnect from the database
        if (MurachDB.disconnect())
            System.out.println("Derby has been shut down.\n");
    }

    public static void printProducts()
    {
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT * FROM Products"))
        {            
            Product p = null;

            System.out.println("Product list:");
            while(rs.next())
            {
                String code = rs.getString("ProductCode");
                String description = rs.getString("Description");
                double price = rs.getDouble("Price");

                p = new Product(code, description, price);

                printProduct(p);
            }
            System.out.println();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void printFirstProduct()
    {
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT * FROM Products"))
        {  
            Product p = null;
            if(rs.next())
            {
                // code that uses column names
                String code = rs.getString("ProductCode");
                String description = rs.getString("Description");
                double price = rs.getDouble("Price");
                p = new Product(code, description, price);

                System.out.println("First product:");
                printProduct(p);
                System.out.println();
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void printLastProduct()
    {
        try
        (
            // Create a scrollable, read-only result set
            Statement statement = connection.createStatement(
              ResultSet.TYPE_SCROLL_INSENSITIVE,
              ResultSet.CONCUR_READ_ONLY);

            // Select all products
            ResultSet rs = statement.executeQuery("SELECT * FROM Products");                
        )
        {
            Product p = null;

            // move to last record
            rs.last();

            // code that uses indexes
            String code = rs.getString("ProductCode");
            String description = rs.getString("Description");
            double price = rs.getDouble("Price");
            p = new Product(code, description, price);

            System.out.println("Last product:");
            printProduct(p);
            System.out.println();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void printProductByCode(String productCode)
    {
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT * FROM Products WHERE ProductCode = ?"))
        {
            Product p = null;
            
            ps.setString(1, productCode);
            ResultSet rs = ps.executeQuery();

            if(rs.next())
            {
                String code = rs.getString("ProductCode");
                String description = rs.getString("Description");
                double price = rs.getDouble("Price");
                p = new Product(code, description, price);

                System.out.println("Product by code: " + productCode);
                printProduct(p);
                System.out.println();
            }

            rs.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    public static void insertProduct(Product p)
    {
        String selectProduct =
            "SELECT * FROM Products WHERE ProductCode = ?";
        String insertProduct =
            "INSERT INTO Products (ProductCode, Description, Price) " +
            "VALUES (?, ?, ?)";
        
        try (PreparedStatement ps = connection.prepareStatement(selectProduct);
             PreparedStatement ps2 = connection.prepareStatement(insertProduct))
        {
            System.out.println("Insert test: ");

            ps.setString(1, p.getCode());
            ResultSet rs = ps.executeQuery();

            if(rs.next())
            {
                System.out.println("This product code already exists: " + p.getCode());
            }
            else
            {
                
                ps2.setString(1, p.getCode());
                ps2.setString(2, p.getDescription());
                ps2.setDouble(3, p.getPrice());
                ps2.executeUpdate();

                printProduct(p);
            }
            System.out.println();

            rs.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    private static void deleteProduct(Product p)
    {
        String deleteProduct =
            "DELETE FROM Products " +
            "WHERE ProductCode = ?";
        
        try (PreparedStatement ps = connection.prepareStatement(deleteProduct))                
        {
            System.out.println("Delete test: ");

            ps.setString(1, p.getCode());
            ps.executeUpdate();
            printProduct(p);
                
            System.out.println();

        }
        catch(SQLException e)
        {
            e.printStackTrace();  // for debugging
        }
    }

    // use this method to print a Product object on a single line
    private static void printProduct(Product p)
    {
        String productString =
            StringUtils.padWithSpaces(p.getCode(), 8) +
            StringUtils.padWithSpaces(p.getDescription(), 44) +
            p.getFormattedPrice();

        System.out.println(productString);
    }
}