/**
 *
 * @author Joshw
 */

public class Employee extends Person
{
    private String SSNumber;
    
    public Employee()
    {
        super();
        this.SSNumber = "111-11-1111"; 
    }

    public String getSSNumber()
    {
        return SSNumber;
    }

    public void setSSNumber( String SSNumber )
    {
        this.SSNumber = SSNumber;
    }
    
    @Override
    public String getDisplayText()
    {
//        super.setFirstName(super.getFirstName());
//        super.setLastName(super.getLastName());
//        super.setEmailAddress(super.getEmailAddress());
        return super.toString() + "\nSocial security number: " 
                                + this.getSSNumber() + "\n";
    }
}
