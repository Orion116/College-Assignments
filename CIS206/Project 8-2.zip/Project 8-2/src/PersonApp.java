///**
// *
// * @author Joshw
// */
//
//public class PersonApp
//{
//    public static void main(String[] args)
//    {
//        Customer c = new Customer();
//        Employee e = new Employee();
//        
//        Print(c);
//        Print(e);
//    }
//    
//    private static void Print(Person pType)
//    {
//        System.out.println(pType.getDisplayText());
//    }
//}
