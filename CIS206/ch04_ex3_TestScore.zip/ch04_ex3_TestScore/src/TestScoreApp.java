import java.util.Scanner;

public class TestScoreApp
{
    public static void main(String[] args)
    {
        // display operational messages
        System.out.println("Please enter test scores" + 
                           " that range from 0 to 100.");
        System.out.println("To end the program enter \"n\".");
        System.out.println();
        
        Scanner sc = new Scanner(System.in);
        String choice = "y";  // Y so serious
        do
        {
            int scoreTotal = 0;
            int scoreCount = 0;
            int testScore = 0;
            
            int numberOfScores = 0;

            System.out.print("Enter The Number Of Test Scores Be Entired: ");            
            numberOfScores = sc.nextInt();
            System.out.println();
            
            for(int i = 0; i < numberOfScores; i++)
            { 
                // get the input from the user
                System.out.print("Enter score: ");
                testScore = sc.nextInt();

                // accumulate score count and score total
                if (testScore <= 100)
                {
                    scoreCount += 1;
                    scoreTotal = scoreTotal + testScore;                 
                }
                else //if (testScore != 999)
                {
                    System.out.println("Invalid entry, not counted");
                    i--;
                }
            }
            
            // display the score count, score total, and average score
            double averageScore = scoreTotal / scoreCount;
            String message = "\n" +
                             "Score count:   " + scoreCount + "\n"
                           + "Score total:   " + scoreTotal + "\n"
                           + "Average score: " + averageScore + "\n";
            System.out.println(message);  
            
            //Coninue button
            System.out.print("Enter More Test Scores? (y/n): ");
            choice = sc.next();
            System.out.println();
        }
        while (choice.equalsIgnoreCase("y"));
    }
}