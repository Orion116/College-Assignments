/*******************************************************
 * 
 *      Programmer: Joshua Wiley
 * 
 *      Date: 9-1-15
 * 
 *      Comments: Fixed exit,  added end summary
 * 
*******************************************************/
import java.util.Scanner;

public class InvoiceApp
{
        public static void main( String[] args )
        {
                 // create a Scanner object named sc
                Scanner sc = new Scanner( System.in );
                
                /*** Variables ***/
                String choice = "y";
                String message = "";
                int invoiceCount = 0;
                double trackTotal = 0.0;
                double trackDiscount = 0.0;
                double avgDiscount = 0.0;
                double avgAmount = 0.0;
                
                // welcome the user to the program
                System.out.println( "Welcome to the Invoice Total Calculator" );
                System.out.println();  // print a blank line

                // perform invoice calculations until choice isn't equal to "y" or "Y"
                while ( !choice.equalsIgnoreCase( "n" ) )
                {
                        // get the invoice subtotal from the user
                        System.out.print( "Enter subtotal:   " );
                        double subtotal = sc.nextDouble();

                        //  Find the discount rate
                        double discountPercent = 0.0; 
                        if ( subtotal >= 500 )
                              discountPercent = .25;
                        else if ( subtotal >= 200 )                        
                              discountPercent = .2;
                        else if ( subtotal >= 100)
                              discountPercent = .1;
                        else
                              discountPercent = 0.0;                           
                        
                        /*** calculate the discount amount and total  ***/
                        double discountAmount = subtotal * discountPercent;
                        double total = subtotal - discountAmount;
                        
                        /*** keeps track of the total and discount ***/
                        trackTotal += total;
                        trackDiscount += discountAmount;                        
                        
                        message =  "Discount percent: " + discountPercent + "\n" +
                                                 "Discount amount:  " + discountAmount + "\n"  +
                                                 "Invoice total:    "         + total + "\n";
                        System.out.println( message );
                        
                        // see if the user wants to continue
                        System.out.print( "Continue? (y/n): " );
                        choice = sc.next();
                        //Add 1 invoice for every time "y" is entered
                        invoiceCount += 1;
                        System.out.println();             
                }
                
                // average
                avgAmount = trackTotal / invoiceCount; 
                avgDiscount = trackDiscount / invoiceCount;
                // display the invoice count, avg discount amount, and avg. total
                message = "Number of Invoices: "        + invoiceCount + "\n" +
                                        "Invoices Avg. Amount:  "  + avgAmount + "\n"      +
                                        "Avg. Discountl:    "               + avgDiscount + "\n";
                System.out.println( message );
        }
}