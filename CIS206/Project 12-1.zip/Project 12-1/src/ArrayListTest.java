
import java.util.ArrayList;

/**
 *
 * @author Joshw
 */
public class ArrayListTest
{
    private static ArrayList<String> cat = new ArrayList<>();

//    public static void main(String args[])
//    {
//
//        cat.add("a");
//        cat.add("b");
//        cat.add("c");
//        cat.add("d");
//        cat.add("e");
//        cat.add("f");
//        cat.add("g");
//        cat.add("h");
//        cat.add("i");
//        cat.add("j");
//        cat.add("k");
//        cat.add("l");
//        cat.add("m");
//        cat.add("n");
//        cat.add("o");
//        cat.add("p");
//        cat.add("q");
//        cat.add("r");
//        cat.add("s");
//        cat.add("t");
//        cat.add("u");
//        cat.add("v");
//        cat.add("w");
//        cat.add("x");
//        cat.add("y");
//        cat.add("z");  
//        
////        while (cat.size() > 0)
////        {            
////            System.out.println(cat.get());
////        } 
////        System.out.println();
//        
//        int count = 5;
//        int i = 0;
//        while (i <= count)
//        {          
//            getMovie(i);
//            ++i;
//        }
//        System.out.println("i = " + i + " Count = " + count + "\n");
//        count += 5;
//        while (i <= count)
//        {          
//            getMovie(i);
//            ++i;
//        }
//        System.out.println("i = " + i + " Count = " + count + "\n");
//        count += 5;
//        while (i <= count)
//        {          
//            getMovie(i);
//            ++i;
//        }
//        System.out.println("i = " + i + " Count = " + count + "\n");
//        count += 5;
//        while (i <= count)
//        {          
//            getMovie(i);
//            ++i;
//        }
//        System.out.println("i = " + i + " Count = " + count + "\n");
//        count += 5;
//        while (i <= count)
//        {          
//            getMovie(i);
//            ++i;
//        }
//        System.out.println("i = " + i + " Count = " + count + "\n");
//        count += 5;
//    }
    
    public static void getMovie(int i)
    {
        System.out.println(cat.get(i));
    }
}
