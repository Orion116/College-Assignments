#include "queue.h"

void enqueue(queueNode **front, queueNode **back, queueNode insertData)
{
    printf("In stubbed out enqueue with data: %lf\n", insertData.appData);
    printf("front: %p back: %p\n", *front, *back);
    return;
}

double dequeue(queueNode **front, queueNode **back)
{
    double retVal = 0;
    printf("In stubbed out dequeue\n");
    printf("front: %p back: %p\n", *front, *back);

    return(retVal);
}

void printAll(queueNode *front, queueNode *back)
{
    printf("In stubbed out printAll\n");
    printf("front: %p back: %p\n", front, back);

    return;
}

bool isEmpty(queueNode *front, queueNode *back)
{
    printf("In stubbed out isEmpty\n");
    printf("front: %p back: %p\n", front, back);

    return(false);
}


void deleteAll(queueNode **front, queueNode **back)
{
    printf("In stubbed out deleteAll\n");
    printf("front: %p back: %p\n", *front, *back);

    return;
}
