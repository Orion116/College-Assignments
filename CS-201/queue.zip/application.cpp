#include <stdio.h>
#include "queue.h"

int main()
{
    queueNode inData, *front = NULL, *back = NULL;
    double myDouble;
    char inChar;
    bool empty;

    do
    {
	printf("Please select one of the following:\n");
	printf("\te/E - Enqueue data\n");
	printf("\td/D - Dequeue data\n");
	printf("\tp/P - Print the contents of the queue\n");
	printf("\ti/I - Check for an empty queue\n");
	printf("\tq/Q - Quit program\n");
        printf("Selection? ");
	scanf("%c", &inChar);
	fflush(stdin);
        switch (inChar)
	{
	    case 'e':
	    case 'E':
		printf("Please enter the real number to enqueue: ");
		scanf("%lf", &inData.appData);
		fflush(stdin);
		enqueue(&front, &back, inData);
		break;

	    case 'd':
	    case 'D':
		printf("Dequeue operation should go here\n");
		myDouble = dequeue(&front, &back);
		break;

	    case 'p':
	    case 'P':
		printf("Print all operation should go here\n");
		printAll(front, back);
		break;

	    case 'i':
	    case 'I':
		printf("Is Empty operation should go here\n");
		empty = isEmpty(front, back);
		break;

	    case 'q':
	    case 'Q':
		printf("Code needed to return entire contents of the\n");
		printf("    queue back to free memory\n");
		deleteAll(&front, &back);
		break;

	    default:
		printf("ERROR: Bad selection %c\n", inChar);
		break;
	}
    } while (inChar != 'Q' && inChar != 'q');
    return(0);
}
