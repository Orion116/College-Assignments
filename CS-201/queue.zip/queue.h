#include <stdio.h>

struct queueNode
{
    double appData;
    queueNode *next;
};

void deleteAll(queueNode **front, queueNode **back);
bool isEmpty(queueNode *front, queueNode *back);
void printAll(queueNode *front, queueNode *back);
double dequeue(queueNode **front, queueNode **back);
void enqueue(queueNode **front, queueNode **back, queueNode insertData)
;
