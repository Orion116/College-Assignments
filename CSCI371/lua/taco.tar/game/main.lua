

require("parse")
require("superparser");
--require("verbs");
require("support")

require("rooms/roomsetup");

-- Require all people
require("people/dog");
require("people/grandma");

-- Require all things
require("things/taco");

-- Require all verbs
require("verbs/talk");
require("verbs/buy");
require("verbs/get");
require("verbs/drop");
require("verbs/inventory");
require("verbs/look");
require("verbs/attack");
require("verbs/give");
require("verbs/use");
require("verbs/eat");



-- Game variables
funds = 50
lastVerb=nil;
karma = 1;
banned= 0;

-- Initialize tables for hold, people, things, and aliases
mapping = { };
items = { };
people = { };
handlers = {};
verbs = {};
nextNumber = 0;

-- --------------------------------------------------------

-- Call people init functions here
Doginit();
Grandmainit();


-- Call item init functions here
Tacoinit();

-- Call verb init functions here
initAttack();
initBuy();
initDrop();
initEat();
initGet();
initGive();
initInventory();
initLook();
initTalk();
initUse();

-- -------------------------------------------------------------
-- Start main loop
-- 
-- New for Spring 16 - Added a tick to the main loop
--
-- ------------------------------------------------------------
location = 1
tickCount = 0;
while ( true ) do
	location = roomMap[location]()
	tickCount = tickCount + 1;
	tick()
end	
