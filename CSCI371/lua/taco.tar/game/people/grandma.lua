--[[
mappings are always 0 = myNumber, and 1=1 (person)

people
	0 -> Full name
	1 -> Location
	2 -> Status 
	3 -> Interact function
	4 -> Tick function

]]--
function Grandmainit()
	local myNumber = nextNumber;
	nextNumber = nextNumber + 1;
	
	mapping["Grandma"] = {[0] = myNumber, [1] = 1};
	mapping["grandma"] = {[0] = myNumber, [1] = 1};
	mapping["Lulu"] = {[0] = myNumber, [1] = 1};
	mapping["Ahmed's grandma"] = {[0] = myNumber, [1] = 1};
	
	people[myNumber] = {[0] = "Ahmed's Grandma Lulu", [1] = 5, [2] = 0, [3] = talkGrandma, [4] = tickGrandma};


end

--[[ Arg is the verb that we tried to use on the person ]]--
function talkGrandma(arg, target)
	local mynum = mapping["Grandma"][0];
	local myStuff = people[mynum];


	if (arg == 0) then
		print (myStuff[0] .. " is standing here.");
	end

	if ((arg == 33) and (target == mapping["taco"][0])) then
		if (items[target][1] == 0) then
			print ("She does not want to eat in the bank");
		else
			print ("Ahmed's grandma is angry with you and adds you to the TSA watch list");
		end
	end
	
end

--[[ Used if this person should do something on their own ]]--
function tickGrandma()
	
end

