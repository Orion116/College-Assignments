
require("../rooms/room0");
require("../rooms/room1");
require("../rooms/room2");
require("../rooms/room3");
require("../rooms/room4");
require("../rooms/room5");
require("../rooms/room6");
require("../rooms/room7");
require("../rooms/room8");
require("../rooms/room9");
require("../rooms/room10");
require("../rooms/room11");
require("../rooms/room12");
require("../rooms/room13");
require("../rooms/room14");
require("../rooms/room15");
require("../rooms/room16");
require("../rooms/room17");
require("../rooms/room18");
require("../rooms/room19");

roomMap = {
	[0] = room0,
	[1] = room1,
	[2] = room2,
	[3] = room3,
	[4] = room4,
	[5] = room5,
	[6] = room6,
	[7] = room7,
	[8] = room8,
	[9] = room9,
	[10] = room10,
	[11] = room11,
	[12] = room12,
	[13] = room13,
	[14] = room14,
	[15] = room15,
	[16] = room16,
	[17] = room17,
	[18] = room18,
	[19] = room19,
	};